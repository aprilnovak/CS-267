#!/bin/bash
#module swap PrgEnv-intel PrgEnv-gnu # for using gnu and gcc
module load bupc
